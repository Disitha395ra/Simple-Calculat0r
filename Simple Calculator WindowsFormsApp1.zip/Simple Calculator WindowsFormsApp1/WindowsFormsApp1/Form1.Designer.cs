﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxnumber1 = new System.Windows.Forms.TextBox();
            this.textBoxnumber2 = new System.Windows.Forms.TextBox();
            this.textBoxresult = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonsub = new System.Windows.Forms.Button();
            this.buttonmul = new System.Windows.Forms.Button();
            this.buttondiv = new System.Windows.Forms.Button();
            this.buttonclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxnumber1
            // 
            this.textBoxnumber1.BackColor = System.Drawing.SystemColors.Info;
            this.textBoxnumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxnumber1.Location = new System.Drawing.Point(470, 100);
            this.textBoxnumber1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxnumber1.Multiline = true;
            this.textBoxnumber1.Name = "textBoxnumber1";
            this.textBoxnumber1.Size = new System.Drawing.Size(298, 76);
            this.textBoxnumber1.TabIndex = 0;
            this.textBoxnumber1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxnumber2
            // 
            this.textBoxnumber2.BackColor = System.Drawing.SystemColors.Info;
            this.textBoxnumber2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxnumber2.Location = new System.Drawing.Point(470, 235);
            this.textBoxnumber2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxnumber2.Multiline = true;
            this.textBoxnumber2.Name = "textBoxnumber2";
            this.textBoxnumber2.Size = new System.Drawing.Size(298, 76);
            this.textBoxnumber2.TabIndex = 1;
            this.textBoxnumber2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxresult
            // 
            this.textBoxresult.BackColor = System.Drawing.SystemColors.Info;
            this.textBoxresult.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxresult.Location = new System.Drawing.Point(470, 383);
            this.textBoxresult.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxresult.Multiline = true;
            this.textBoxresult.Name = "textBoxresult";
            this.textBoxresult.Size = new System.Drawing.Size(298, 79);
            this.textBoxresult.TabIndex = 2;
            this.textBoxresult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(220, 100);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 76);
            this.label1.TabIndex = 3;
            this.label1.Text = "Number 01";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(220, 235);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 76);
            this.label2.TabIndex = 4;
            this.label2.Text = "Number 02";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(220, 383);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 79);
            this.label3.TabIndex = 5;
            this.label3.Text = "Result";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdd.Location = new System.Drawing.Point(855, 100);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(153, 83);
            this.buttonAdd.TabIndex = 6;
            this.buttonAdd.Text = "+";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.ButtonAdd_Click);
            // 
            // buttonsub
            // 
            this.buttonsub.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsub.Location = new System.Drawing.Point(855, 212);
            this.buttonsub.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonsub.Name = "buttonsub";
            this.buttonsub.Size = new System.Drawing.Size(153, 83);
            this.buttonsub.TabIndex = 7;
            this.buttonsub.Text = "-";
            this.buttonsub.UseVisualStyleBackColor = false;
            this.buttonsub.Click += new System.EventHandler(this.Buttonsub_Click);
            // 
            // buttonmul
            // 
            this.buttonmul.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonmul.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonmul.Location = new System.Drawing.Point(855, 322);
            this.buttonmul.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonmul.Name = "buttonmul";
            this.buttonmul.Size = new System.Drawing.Size(153, 83);
            this.buttonmul.TabIndex = 8;
            this.buttonmul.Text = "*";
            this.buttonmul.UseVisualStyleBackColor = false;
            this.buttonmul.Click += new System.EventHandler(this.Buttonmul_Click);
            // 
            // buttondiv
            // 
            this.buttondiv.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttondiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondiv.Location = new System.Drawing.Point(855, 431);
            this.buttondiv.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttondiv.Name = "buttondiv";
            this.buttondiv.Size = new System.Drawing.Size(153, 83);
            this.buttondiv.TabIndex = 9;
            this.buttondiv.Text = "/";
            this.buttondiv.UseVisualStyleBackColor = false;
            this.buttondiv.Click += new System.EventHandler(this.Buttondiv_Click);
            // 
            // buttonclear
            // 
            this.buttonclear.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonclear.Location = new System.Drawing.Point(542, 520);
            this.buttonclear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(153, 83);
            this.buttonclear.TabIndex = 10;
            this.buttonclear.Text = "AC";
            this.buttonclear.UseVisualStyleBackColor = false;
            this.buttonclear.Click += new System.EventHandler(this.Buttonclear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.buttonclear);
            this.Controls.Add(this.buttondiv);
            this.Controls.Add(this.buttonmul);
            this.Controls.Add(this.buttonsub);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxresult);
            this.Controls.Add(this.textBoxnumber2);
            this.Controls.Add(this.textBoxnumber1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxnumber1;
        private System.Windows.Forms.TextBox textBoxnumber2;
        private System.Windows.Forms.TextBox textBoxresult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonsub;
        private System.Windows.Forms.Button buttonmul;
        private System.Windows.Forms.Button buttondiv;
        private System.Windows.Forms.Button buttonclear;
    }
}

