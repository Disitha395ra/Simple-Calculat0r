﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            double number1 = Convert.ToDouble(this.textBoxnumber1.Text);
            double number2 = Convert.ToDouble(this.textBoxnumber2.Text);
            double add = number1+number2;
            this.textBoxresult.Text = add.ToString();
            //this.textBoxresult.Text=(Convert.ToDouble(this.textBoxnumber1.Text)+(Convert.ToDouble(this.textBoxnumber2.Text);
        }

        private void Buttonsub_Click(object sender, EventArgs e)
        {
            double number1 = Convert.ToDouble(this.textBoxnumber1.Text);
            double number2 = Convert.ToDouble(this.textBoxnumber2.Text);
            double sub = number1 - number2;
            this.textBoxresult.Text = sub.ToString();
        }

        private void Buttonmul_Click(object sender, EventArgs e)
        {
            double number1 = Convert.ToDouble(this.textBoxnumber1.Text);
            double number2 = Convert.ToDouble(this.textBoxnumber2.Text);
            double multi = number1 * number2;
            this.textBoxresult.Text = multi.ToString();
        }

        private void Buttondiv_Click(object sender, EventArgs e)
        {
            double number1 = Convert.ToDouble(this.textBoxnumber1.Text);
            double number2 = Convert.ToDouble(this.textBoxnumber2.Text);
            double divident = number1 / number2;
            this.textBoxresult.Text = divident.ToString();
        }

        private void Buttonclear_Click(object sender, EventArgs e)
        {
            textBoxnumber1.Clear();
            textBoxnumber2.Clear();
            textBoxresult.Clear();
            ShowButtons();
        }

       
private void textBoxnumber1_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show(textBoxnumber1.Text);
            int result = 0;
            if(int.TryParse(textBoxnumber1.Text, out result))
            {
                //MessageBox.Show("Valid number");
                //this.buttonAdd.Show();
                ShowButtons();
            }
            else
            {
                //MessageBox.Show("InValid number");
                //this.buttonAdd.Hide();
                HideButtons();
            }
        }

        private void HideButtons()
        {
            this.buttonAdd.Hide();
            this.buttonsub.Hide();
            this.buttondiv.Hide();
            this.buttonmul.Hide();
        }

        private void ShowButtons()
        {
            this.buttonAdd.Show();
            this.buttonsub.Show();
            this.buttondiv.Show();
            this.buttonmul.Show();
        }
    }
}
